﻿using MediatR;
using Persistence.Repositories;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace Core.Features.Commands.DeleteTableSpecification
{
    public class DeleteTableSpecificationHandler : IRequestHandler<DeleteTableSpecificationCommand, bool>
    {
        private readonly ITableSpecificationRepository _tableSpecificationRepository;

        public DeleteTableSpecificationHandler(ITableSpecificationRepository tableSpecificationRepository)
        {
            _tableSpecificationRepository = tableSpecificationRepository;
        }

        public async Task<bool> Handle(DeleteTableSpecificationCommand command, CancellationToken cancellationToken)
        {
            var success = await _tableSpecificationRepository.DeleteAsync(command.TableId);
            return success;
        }
    }
}