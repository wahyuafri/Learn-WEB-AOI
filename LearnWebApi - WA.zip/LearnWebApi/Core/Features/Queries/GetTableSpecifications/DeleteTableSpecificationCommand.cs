﻿using MediatR;

namespace Core.Features.Commands.DeleteTableSpecification
{
    public class DeleteTableSpecificationCommand : IRequest<bool>
    {
        public Guid TableId { get; set; }
    }
}