using MediatR;
using Persistence.Repositories;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace Core.Features.Queries.GetTableSpecifications;

public class GetTableSpecificationsHandler : IRequestHandler<GetTableSpecificationsQuery, GetTableSpecificationsResponse>
{
    private readonly ITableSpecificationRepository _tableSpecificationRepository;

    public GetTableSpecificationsHandler(ITableSpecificationRepository tableSpecificationRepository)
    {
        _tableSpecificationRepository = tableSpecificationRepository;
    }

    public async Task<GetTableSpecificationsResponse> Handle(GetTableSpecificationsQuery query, CancellationToken cancellationToken)
    {
        var tableSpecification = await _tableSpecificationRepository.GetByIdAsync(query.TableSpecificationId);
        
        if (tableSpecification is null)
        {
            return new GetTableSpecificationsResponse();
        }

        var response = new GetTableSpecificationsResponse()
        {
            TableId = tableSpecification.TableId,
            TableNumber = tableSpecification.TableNumber,
            ChairNumber = tableSpecification.ChairNumber,
            TablePic = tableSpecification.TablePic,
            TableType = tableSpecification.TableType
        };
        
        return response;
    }
}