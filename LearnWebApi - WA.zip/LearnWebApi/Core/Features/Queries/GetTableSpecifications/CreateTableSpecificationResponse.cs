﻿using System.ComponentModel.DataAnnotations;

namespace Core.Features.Commands.CreateTableSpecification
{
    public class CreateTableSpecificationResponse
    {
        [Required]
        public Guid TableId { get; set; }
        public int TableNumber { get; set; }
        public int ChairNumber { get; set; }
        [Required]
        public string TablePic { get; set; }
        public string? TableType { get; set; }
    }
}