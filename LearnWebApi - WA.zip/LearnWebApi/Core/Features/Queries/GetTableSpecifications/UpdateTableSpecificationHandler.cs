﻿using MediatR;
using Persistence.Models;
using Persistence.Repositories;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace Core.Features.Commands.UpdateTableSpecification
{
    public class UpdateTableSpecificationHandler : IRequestHandler<UpdateTableSpecificationCommand, UpdateTableSpecificationResponse>
    {
        private readonly ITableSpecificationRepository _tableSpecificationRepository;

        public UpdateTableSpecificationHandler(ITableSpecificationRepository tableSpecificationRepository)
        {
            _tableSpecificationRepository = tableSpecificationRepository;
        }

        public async Task<UpdateTableSpecificationResponse> Handle(UpdateTableSpecificationCommand command, CancellationToken cancellationToken)
        {
            var tableSpecification = await _tableSpecificationRepository.GetByIdAsync(command.TableId);
            if (tableSpecification == null)
            {
                // Handle not found scenario (e.g., throw exception, return null, etc.)
                return null;
            }

            if (command.TableNumber != 0) tableSpecification.TableNumber = command.TableNumber;
            if (command.ChairNumber != 0) tableSpecification.ChairNumber = command.ChairNumber;
            if (command.TablePic != null) tableSpecification.TablePic = command.TablePic;
            if (command.TableType != null) tableSpecification.TableType = command.TableType;

            await _tableSpecificationRepository.UpdateAsync(tableSpecification);

            return new UpdateTableSpecificationResponse
            {
                TableId = tableSpecification.TableId,
                TableNumber = tableSpecification.TableNumber,
                ChairNumber = tableSpecification.ChairNumber,
                TablePic = tableSpecification.TablePic,
                TableType = tableSpecification.TableType
            };
        }
    }
}