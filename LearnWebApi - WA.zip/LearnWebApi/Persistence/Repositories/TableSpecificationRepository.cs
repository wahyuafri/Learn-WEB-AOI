using System;
using System.Threading.Tasks;
using Persistence.Models;
using Persistence.DatabaseContext;
using Microsoft.EntityFrameworkCore;

namespace Persistence.Repositories
{
    public class TableSpecificationRepository : GenericRepository<TableSpecification>, ITableSpecificationRepository
    {
        public TableSpecificationRepository(TableContext context) : base(context)
        {
        }
    }
}